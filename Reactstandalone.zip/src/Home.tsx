import { ColumnDirective, ColumnsDirective, GridComponent } from '@syncfusion/ej2-react-grids';
import { TooltipComponent } from '@syncfusion/ej2-react-popups';
import { Inject, Page} from '@syncfusion/ej2-react-grids';
import React from 'react';
import { data } from './datasource';
import { DataManager, UrlAdaptor, DataUtil, Deferred } from '@syncfusion/ej2-data';
import { isNullOrUndefined, extend, Fetch } from '@syncfusion/ej2-base'
import { debug } from 'console';

function Home() {
  let gridInstance: any;
  let toolTip: any;

  const beforeRender = ((args: any) => {
    toolTip.content = 'This is value "' + args.target.innerText + '" ';
    if (args.target.classList.contains('e-rowcell') ) {
      if(args.target.scrollWidth > args.target.clientWidth) {
        toolTip.content = 'This is value "' + args.target.innerText + '" ';
      }
      else {
        args.cancel = true;
      }
      
    }
    else if(args.target.classList.contains('e-headercell')) {
      if(args.target.querySelector('.e-headercelldiv').scrollWidth > args.target.querySelector('.e-headercelldiv').clientWidth) {
        toolTip.content = 'This is value "' + args.target.innerText + '" ';
      }
      else {
        args.cancel = true;
      }
    }
  });

   return(<div> <p>Grid-1 using Functional Components</p>
   <TooltipComponent ref={t => toolTip = t} beforeRender={beforeRender} target=".e-headercell,.e-rowcell">
   <GridComponent dataSource={data} width={400} height={315}>
          <ColumnsDirective>
            <ColumnDirective field='OrderID' headerText='OrderID' width='100' />
            <ColumnDirective field='CustomerID' headerText='Customer ID Customer ID Customer ID Customer ID' width='110' />
            <ColumnDirective field='Freight' headerText='Freight' format='C' width='80' />
            <ColumnDirective field='ShipCity' headerText='ShipCity' width='100' />
          </ColumnsDirective>
        </GridComponent>
</TooltipComponent>
        </div>
)
    }
    

export default Home;