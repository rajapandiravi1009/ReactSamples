import * as React from 'react';
import Home from './Home';

export default class App extends React.Component<{}, {}>{
    
    public render() {
        return  <div> 
            <Home/> 
         </div> 
        
    }
};