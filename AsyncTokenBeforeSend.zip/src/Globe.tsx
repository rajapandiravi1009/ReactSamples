import React from 'react';
import { DataManager, UrlAdaptor, DataUtil, Deferred } from '@syncfusion/ej2-data';
import { isNullOrUndefined, extend, Fetch } from '@syncfusion/ej2-base';
import { fetchToken } from './App'


export function makeRequestFun() {

    (DataManager.prototype as any).makeRequest = function(url: any, deffered: any, args: any, query: any) {
        const _this = this;
        let isSelector = !!query.subQuerySelector;
        let fnFail = function (e:any, req: any) {
            args.error = e;
            deffered.reject(args);
        };
        let process: any = function (data: any, count: any, xhr: any, request: any, actual: any, aggregates: any, virtualSelectRecords: any) {
            args.xhr = xhr;
            args.count = count ? parseInt(count.toString(), 10) : 0;
            args.result = data;
            args.request = request;
            args.aggregates = aggregates;
            args.actual = actual;
            args.virtualSelectRecords = virtualSelectRecords;
            deffered.resolve(args);
        };
        let fnQueryChild = function (data: any, selector: any) {
            let subDeffer = new Deferred();
            let childArgs = { parent: args };
            query.subQuery.isChild = true;
            let subUrl = _this.adaptor.processQuery(_this, query.subQuery, data ? _this.adaptor.processResponse(data) : selector);
            let childReq = _this.makeRequest(subUrl, subDeffer, childArgs, query.subQuery);
            if (!isSelector) {
                subDeffer.then(function (subData: any) {
                    if (data) {
                        DataUtil.buildHierarchy(query.subQuery.fKey, query.subQuery.fromTable, data, subData, query.subQuery.key);
                        process(data, subData.count, subData.xhr);
                    }
                }, fnFail);
            }
            return childReq;
        };
        let fnSuccess = function (data: any, request: any) {
            if (_this.isGraphQLAdaptor(_this.adaptor)) {
                // tslint:disable-next-line:no-string-literal
                if (!isNullOrUndefined(data['errors'])) {
                    // tslint:disable-next-line:no-string-literal
                    return fnFail(data['errors'], request);
                }
            }
            if (_this.isCustomDataAdaptor(_this.adaptor)) {
                request = extend({}, _this.fetchReqOption, request);
            }
            if (request.contentType.indexOf('xml') === -1 && _this.dateParse) {
                data = (DataUtil as any).parse.parseJson(data);
            }
            let result = _this.adaptor.processResponse(data, _this, query, request.fetchRequest, request);
            let count = 0;
            let aggregates = null;
            let virtualSelectRecords = 'virtualSelectRecords';
            let virtualRecords = data[virtualSelectRecords];
            if (query.isCountRequired) {
                count = result.count;
                aggregates = result.aggregates;
                result = result.result;
            }
            if (!query.subQuery) {
                process(result, count, request.fetchRequest, request.type, data, aggregates, virtualRecords);
                return;
            }
            if (!isSelector) {
                fnQueryChild(result, request);
            }
        };
        let req = this.extendRequest(url, fnSuccess, fnFail);
        if (!this.isCustomDataAdaptor(this.adaptor)) {
            let fetch_1 = new Fetch(req);
            fetch_1.beforeSend = function () {
                _this.beforeSend(fetch_1.fetchRequest, fetch_1);
            };
            
            fetchToken().then(mov => {
              (window as any).token = mov;
              req = fetch_1.send();

              req.catch(function (e: any) { return true; }); // to handle failure remote requests.
            });
            
            
            this.requests.push(fetch_1);
        }
        else {
            this.fetchReqOption = req;
            let request = req;
            this.adaptor.options.getData({
                data: request.data,
                onSuccess: request.onSuccess, onFailure: request.onFailure
            });
        }
        if (isSelector) {
            let promise: any = void 0;
            let res = query.subQuerySelector.call(this, { query: query.subQuery, parent: query });
            if (res && res.length) {
                promise = Promise.all([req, fnQueryChild(null, res)]);
                promise.then(function () {
                    let args = [];
                    for (let _i = 0; _i < arguments.length; _i++) {
                        args[_i] = arguments[_i];
                    }
                    let result = args[0];
                    let pResult = _this.adaptor.processResponse(result[0], _this, query, _this.requests[0].fetchRequest, _this.requests[0]);
                    let count = 0;
                    if (query.isCountRequired) {
                        count = pResult.count;
                        pResult = pResult.result;
                    }
                    let cResult = _this.adaptor.processResponse(result[1], _this, query.subQuery, _this.requests[1].fetchRequest, _this.requests[1]);
                    count = 0;
                    if (query.subQuery.isCountRequired) {
                        count = cResult.count;
                        cResult = cResult.result;
                    }
                    DataUtil.buildHierarchy(query.subQuery.fKey, query.subQuery.fromTable, pResult, cResult, query.subQuery.key);
                    isSelector = false;
                    process(pResult, count, _this.requests[0].fetchRequest);
                });
            }
            else {
                isSelector = false;
            }
        }
        return req;
  }

}