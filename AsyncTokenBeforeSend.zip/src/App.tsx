import React from 'react';
import './App.css';
import { ColumnDirective, ColumnsDirective, GridComponent } from '@syncfusion/ej2-react-grids';
import { Inject, Page } from '@syncfusion/ej2-react-grids';
import { DataManager, UrlAdaptor, DataUtil, Deferred } from '@syncfusion/ej2-data';
import { isNullOrUndefined, extend, Fetch } from '@syncfusion/ej2-base'
import { debug } from 'console';
import { makeRequestFun } from './Globe';

export class CustomUrlAdaptor extends UrlAdaptor {
  public beforeSend(dm: any, request: any) {
    if ((window as any).token) {
      request.headers.set('Authorization', 'Bearer ' + (window as any).token);
      // additional headers sent here
    }
    super.beforeSend(dm, request);
  }


}

export async function fetchToken() {
  const response = await fetch("https://services.odata.org/V4/Northwind/Northwind.svc/Orders");
  const movies = await response.json();
  return "New Token";
}



function App() {
  let gridInstance: any;
  let token: any;
  const data = new DataManager({
    url: 'https://services.syncfusion.com/js/production/api/UrlDataSource',
    adaptor: new CustomUrlAdaptor(),
  });

  function load() {
    console.log(gridInstance);
    makeRequestFun();
  }

  return (<div> <p>Grid-1 using Functional Components</p>
    <GridComponent id="Grid" dataSource={data} load={load} ref={grid => gridInstance = grid} allowPaging={true}>
      <ColumnsDirective>
        <ColumnDirective field='EmployeeID' headerText='Employee ID' width='120' />
        <ColumnDirective field='Employees' headerText='Employee Name' width='120' />
        <ColumnDirective field='Designation' headerText='Designation' width='160' />
        <ColumnDirective field='CurrentSalary' headerText='Current Salary' width='150' />
      </ColumnsDirective>
      <Inject services={[Page]} />
    </GridComponent>
  </div>
  )
}


export default App;